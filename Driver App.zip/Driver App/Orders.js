import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Orders = () => {
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        fetchOrders();
        const intervalId = setInterval(fetchOrders, 60000); // Update every minute
        return () => clearInterval(intervalId); // Cleanup interval on component unmount
    }, []);

    const fetchOrders = async () => {
        const response = await axios.get('http://localhost:5000/orders');
        setOrders(response.data);
    };

    const updateOrderStatus = async (id, status) => {
        await axios.put(http://localhost:5000/orders/${id}, { status });
        fetchOrders();
    };

    return (
        <div>
            <h1>Orders</h1>
            <ul>
                {orders.map(order => (
                    <li key={order._id}>
                        <p>Customer: {order.customerName}</p>
                        <p>Address: {order.deliveryAddress}</p>
                        <p>Status: {order.status}</p>
                        <button onClick={() => updateOrderStatus(order._id, 'Delivered')}>Mark as Delivered</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Orders;
