// Api.js 
app.get('/orders', async (req, res) => {
    const orders = await Order.find();
    res.json(orders);
});

app.post('/orders', async (req, res) => {
    const newOrder = new Order(req.body);
    await newOrder.save();
    res.json(newOrder);
});

app.put('/orders/:id', async (req, res) => {
    const order = await Order.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(order);
});

app.listen(5000, () => {
    console.log('Server is running on port 5000');
});