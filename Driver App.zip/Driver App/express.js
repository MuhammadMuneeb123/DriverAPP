const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/delivery-app', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Order schema
const orderSchema = new mongoose.Schema({
    customerName: String,
    deliveryAddress: String,
    status: String,
    timestamp: { type: Date, default: Date.now },
});

const Order = mongoose.model('Order', orderSchema);
