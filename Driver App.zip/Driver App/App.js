import React from 'react';
import Orders from './Orders';
import './App.css';

const App = () => {
    return (
        <div className="App">
            <Orders />
        </div>
    );
};

export default App;
